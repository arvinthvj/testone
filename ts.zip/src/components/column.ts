export default  [ 
    {
        Header:'Id',
        accessor: 'id'
    },
    {
        Header:'First Name',
        accessor: 'first_name'
    },
    {
        Header:'Trips',
        accessor: 'last_name'
    },
    /* {
        Header:'Id',
        accessor: '_id'
    },
    {
        Header:'Id',
        accessor: '_id'
    },
    {
        Header:'Id',
        accessor: '_id'
    } */
]